<?php

namespace App\Models\Entity;

use Illuminate\Database\Eloquent\Model;

class TempEmail extends Model
{
    //
}
