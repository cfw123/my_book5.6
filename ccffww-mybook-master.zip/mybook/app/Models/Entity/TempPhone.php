<?php

namespace App\Models\Entity;

use Illuminate\Database\Eloquent\Model;

class TempPhone extends Model
{
    //
    protected $guarded =[];
}
