<?php

namespace App\Models\Entity;

use Illuminate\Database\Eloquent\Model;

class PdtImages extends Model
{
    //
}
