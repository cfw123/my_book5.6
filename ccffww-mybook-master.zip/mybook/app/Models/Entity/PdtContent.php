<?php

namespace App\Models\Entity;

use Illuminate\Database\Eloquent\Model;

class PdtContent extends Model
{
    //
}
